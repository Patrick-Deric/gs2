package com.example.gs2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
